"""
TabPFN foundation prior model runners with RankGauss Quantile transformation.
"""

import time
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from sklearn.preprocessing import QuantileTransformer
from catboost import CatBoostClassifier

from src.config import HAS_GPU, NUM_GPUS
from src.metrics import competition_score

try:
    from tabpfn import TabPFNClassifier
    HAS_TABPFN = True
except ImportError:
    TabPFNClassifier = None
    HAS_TABPFN = False


def fit_tabpfn_multi_view(
    X_train: pd.DataFrame,
    y_true: np.ndarray,
    X_test: pd.DataFrame,
    folds: List[Tuple[np.ndarray, np.ndarray]],
    pfn_views: Dict[str, List[str]],
) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """
    Fits foundation TabPFN priors over specialized feature sub-views.
    Falls back to orthogonal CatBoost models if TabPFN or CUDA is unavailable.
    """
    n_train = len(X_train)
    n_test = len(X_test)
    n_splits = len(folds)
    oof_dict: Dict[str, np.ndarray] = {}
    test_dict: Dict[str, np.ndarray] = {}

    use_surrogate = not (HAS_TABPFN and HAS_GPU)
    if HAS_TABPFN and HAS_GPU:
        try:
            print("Training Dual TabPFN Foundation Priors", flush=True)
            for pfn_name, pfn_cols in pfn_views.items():
                t_v0 = time.time()
                avail_cols = [c for c in pfn_cols if c in X_train.columns]
                qt = QuantileTransformer(n_quantiles=1000, output_distribution="normal", random_state=42)
                X_tr_norm = qt.fit_transform(X_train[avail_cols].select_dtypes(include="number").fillna(0))
                X_te_norm = qt.transform(X_test[avail_cols].select_dtypes(include="number").fillna(0))
                pfn_oof = np.zeros(n_train, dtype=float)
                pfn_test = np.zeros(n_test, dtype=float)

                for fold, (trn_idx, val_idx) in enumerate(folds):
                    t_f = time.time()
                    pfn_dev = f"cuda:{fold % NUM_GPUS}" if NUM_GPUS > 1 else "cuda:0"
                    clf = TabPFNClassifier(
                        device=pfn_dev,
                        ignore_pretraining_limits=True,
                        n_estimators=4,
                        random_state=42 + fold,
                    )
                    clf.fit(X_tr_norm[trn_idx], y_true[trn_idx])
                    va_p = clf.predict_proba(X_tr_norm[val_idx])[:, 1]
                    te_p = clf.predict_proba(X_te_norm)[:, 1]
                    pfn_oof[val_idx] = va_p
                    pfn_test += te_p / n_splits
                    print(f"{pfn_name}: Fold {fold+1}/{n_splits} complete ({time.time() - t_f:.1f}s)", flush=True)

                oof_dict[pfn_name] = pfn_oof
                test_dict[pfn_name] = pfn_test
                ll, auc, comp = competition_score(y_true, pfn_oof)
                print(f"{pfn_name}: LL={ll:.5f}, AUC={auc:.5f}, Comp={comp:.5f} ({time.time() - t_v0:.1f}s)", flush=True)
        except Exception as e:
            print(f"TabPFN execution failed ({e}), falling back to CatBoost surrogate.", flush=True)
            use_surrogate = True

    if use_surrogate:
        print("Using CatBoost surrogate priors", flush=True)
        for pfn_name, pfn_cols in pfn_views.items():
            t_v0 = time.time()
            avail_cols = [c for c in pfn_cols if c in X_train.columns]
            m_cb = CatBoostClassifier(depth=6, iterations=400, learning_rate=0.04, verbose=0, random_seed=42)
            if HAS_GPU:
                m_cb.set_params(task_type="GPU")
            m_oof, m_test = np.zeros(n_train), np.zeros(n_test)
            for fold, (trn_idx, val_idx) in enumerate(folds):
                m_cb.fit(X_train.iloc[trn_idx][avail_cols], y_true[trn_idx])
                m_oof[val_idx] = m_cb.predict_proba(X_train.iloc[val_idx][avail_cols])[:, 1]
                m_test += m_cb.predict_proba(X_test[avail_cols])[:, 1] / n_splits

            oof_dict[pfn_name] = m_oof
            test_dict[pfn_name] = m_test
            ll, auc, comp = competition_score(y_true, m_oof)
            print(f"Surrogate {pfn_name}: LL={ll:.5f}, AUC={auc:.5f}, Comp={comp:.5f} ({time.time() - t_v0:.1f}s)", flush=True)

    return oof_dict, test_dict
