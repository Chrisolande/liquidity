"""
Stage 5: Multi-Stage Meta-Stacker, Hill Climbing, and Final Submission Generator.
Integrates all model streams into the winning composite ensemble.
"""

import os
from pathlib import Path
from typing import Dict, List
import numpy as np
import pandas as pd

from src.config import (
    ID_COL,
    TARGET,
    FLOOR,
    CEIL,
    get_default_dataset_paths,
)
from src.ensemble.stacking import blend_and_calibrate, nelder_mead_blend, hill_climb_blend
from src.ensemble.calibration import platt_scaling_calibrate
from src.metrics import competition_score, paired_bootstrap, print_correlation_matrix


def run_stage5(
    ckpt_dir: str = "checkpoints",
    sub_dir: str = "submissions",
    test_path: str = None,
) -> float:
    """Executes Stage 5 Meta-Stacker and final verification."""
    print("Stage 5: Meta-Stacker and Hill Climbing Optimizer")

    os.makedirs(sub_dir, exist_ok=True)
    if not test_path:
        _, test_path = get_default_dataset_paths()
    test_df = pd.read_csv(test_path)

    y_path = os.path.join(ckpt_dir, "y_true.npy")
    if not os.path.exists(y_path):
        raise FileNotFoundError(f"Missing '{y_path}'. Run earlier stages first to populate checkpoints.")

    y_true = np.load(y_path)
    n_train = len(y_true)
    n_test = len(test_df)

    oof_dict: Dict[str, np.ndarray] = {}
    test_dict: Dict[str, np.ndarray] = {}

    # 1. Champion Anchor
    s1_oof_candidates = [
        os.path.join(ckpt_dir, "oof_champ_train.npy"),
        os.path.join("pulled", "oof_champ_train.npy"),
    ]
    s1_oof_path = next((p for p in s1_oof_candidates if os.path.exists(p)), None)

    s1_sub_candidates = [
        os.path.join(sub_dir, "submission_s2_gbdt_zoo.csv"),
        os.path.join("pulled", "submission_s2_gbdt_zoo.csv"),
        os.path.join(sub_dir, "submission_stage1_hillclimb.csv"),
        os.path.join("pulled", "submission_stage1_hillclimb.csv"),
        os.path.join(sub_dir, "submission_best_0.73731.csv"),
        os.path.join("pulled", "submission_baseline.csv"),
    ]
    s1_sub_path = next((p for p in s1_sub_candidates if os.path.exists(p)), None)

    if s1_oof_path and s1_sub_path:
        oof_dict["champ_anchor"] = np.load(s1_oof_path)
        test_dict["champ_anchor"] = pd.read_csv(s1_sub_path)["Target"].values
        print(f"Loaded Champion Anchor: {s1_oof_path}")

    # 2. TabPFN Priors
    s3_candidates = [
        os.path.join(ckpt_dir, "tabpfn.npz"),
        os.path.join("pulled", "tabpfn.npz"),
        os.path.join(ckpt_dir, "tabpfn_priors.npz"),
        os.path.join(ckpt_dir, "experiments", "tabpfn_view_sweep.npz"),
        os.path.join("pulled", "tabpfn_view_sweep.npz"),
    ]
    s3_path = next((p for p in s3_candidates if os.path.exists(p)), None)
    if s3_path:
        data = np.load(s3_path)
        for k in ["tabpfn", "pfn_phys", "pfn_champ", "pfn_sweetspot_50", "pfn_phys_legacy"]:
            oof_k = next((x for x in [f"oof_{k}", f"{k}_oof", k] if x in data), None)
            test_k = next((x for x in [f"test_{k}", f"{k}_test", f"te_{k}"] if x in data), None)
            if oof_k:
                oof_dict[f"pfn_{k}"] = data[oof_k]
                if test_k:
                    test_dict[f"pfn_{k}"] = data[test_k]
                else:
                    test_dict[f"pfn_{k}"] = np.full(n_test, float(data[oof_k].mean()))

    # 3. MultiStrata Iterative Stratification
    ms_candidates = [
        os.path.join(ckpt_dir, "multistrata.npz"),
        os.path.join("pulled", "multistrata.npz"),
    ]
    ms_path = next((p for p in ms_candidates if os.path.exists(p)), None)
    if ms_path:
        data = np.load(ms_path)
        k_ms = next((x for x in ["oof_raw", "oof_multistrata", "p_ms_oof"] if x in data), None)
        k_te = next((x for x in ["test_raw", "test_multistrata", "p_ms_test"] if x in data), None)
        if k_ms and k_te:
            oof_dict["multistrata"] = data[k_ms]
            test_dict["multistrata"] = data[k_te]

    # 4. Neural TabMLP
    mlp_candidates = [
        os.path.join(ckpt_dir, "tab_mlp_fast.npz"),
        os.path.join("pulled", "tab_mlp_fast.npz"),
    ]
    mlp_path = next((p for p in mlp_candidates if os.path.exists(p)), None)
    if mlp_path:
        data = np.load(mlp_path)
        if "oof_mlp" in data and "test_mlp" in data:
            oof_dict["tab_mlp"] = data["oof_mlp"]
            test_dict["tab_mlp"] = data["test_mlp"]

    # 5. Distillation Students
    distill_candidates = [
        os.path.join(ckpt_dir, "distill_student_10fold.npz"),
        os.path.join("pulled", "distill_student_10fold.npz"),
    ]
    distill_path = next((p for p in distill_candidates if os.path.exists(p)), None)
    if distill_path:
        data = np.load(distill_path)
        if "oof_student_lgb" in data:
            oof_dict["student_lgb"] = data["oof_student_lgb"]
            test_dict["student_lgb"] = data["test_student_lgb"]
        if "oof_student_xgb" in data:
            oof_dict["student_xgb"] = data["oof_student_xgb"]
            test_dict["student_xgb"] = data["test_student_xgb"]

    print(f"Total streams assembled for Meta-Stacker: {len(oof_dict)}")
    for k in oof_dict:
        k_ll, k_auc, k_comp = competition_score(y_true, oof_dict[k])
        print(f"  Stream {k:<18}: Comp={k_comp:.5f} | AUC={k_auc:.5f} | LL={k_ll:.5f}")

    print_correlation_matrix(oof_dict)

    # Hill climb and SLSQP blend
    weight_map, oof_blend, test_blend, cal_oof, cal_test = blend_and_calibrate(
        oof_dict=oof_dict,
        test_dict=test_dict,
        y_true=y_true,
        n_splits=5,
    )

    print("\nLearned Model Weights:")
    for k, w in weight_map.items():
        print(f"  {k:<20}: {w:.4f}")

    oof_df = pd.DataFrame(oof_dict)
    test_pred_df = pd.DataFrame(test_dict)
    hc_res = hill_climb_blend(oof_df, test_pred_df, y_true)

    base_comp = competition_score(y_true, cal_oof)[2]
    if hc_res is not None and hc_res[2] > base_comp:
        print(f"Hill Climbing score: {hc_res[2]:.5f} > {base_comp:.5f}")
        candidate_oof = hc_res[0]
        candidate_test = hc_res[1]
    else:
        candidate_oof = cal_oof
        candidate_test = cal_test

    # Tail smoothing floor sweep [0.0020, 0.0025, 0.0030, 0.0035, 0.0040]
    best_floor = 0.0020
    best_floor_comp = competition_score(y_true, np.clip(candidate_oof, FLOOR, CEIL))[2]
    for fl in [0.0020, 0.0025, 0.0030, 0.0035, 0.0040]:
        c_oof = np.clip(candidate_oof, fl, CEIL)
        _, _, fl_comp = competition_score(y_true, c_oof)
        print(f"  Floor {fl:.4f} -> Comp: {fl_comp:.5f}")
        if fl_comp > best_floor_comp:
            best_floor_comp = fl_comp
            best_floor = fl

    final_oof = np.clip(candidate_oof, best_floor, CEIL)
    final_test = np.clip(candidate_test, best_floor, CEIL)

    final_ll, final_auc, final_comp = competition_score(y_true, final_oof)
    print(f"\n================================================================================")
    print(f"STAGE 5 FINAL META-STACKER: Comp={final_comp:.5f} | AUC={final_auc:.5f} | LL={final_ll:.5f} (Floor={best_floor:.4f})")
    print(f"================================================================================")

    out_csv = os.path.join(sub_dir, "submission_stage5_final.csv")
    sub_df = pd.DataFrame({ID_COL: test_df[ID_COL], "Target": final_test})
    sub_df.to_csv(out_csv, index=False)

    champ_out_csv = os.path.join(sub_dir, f"submission_champion_{final_comp:.5f}.csv")
    sub_df.to_csv(champ_out_csv, index=False)

    np.save(os.path.join(ckpt_dir, f"oof_stage5_{final_comp:.5f}.npy"), final_oof)
    print(f"Saved final submission to {out_csv} and {champ_out_csv}")
    return final_comp


if __name__ == "__main__":
    run_stage5()
