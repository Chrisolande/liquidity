"""
Probability calibration routines: Platt Scaling (Logistic Regression) and Isotonic Regression.
"""

from typing import Tuple
import numpy as np
from scipy.special import logit
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression

from src.config import FLOOR, CEIL, EPS


def platt_scaling_calibrate(
    oof_prob: np.ndarray,
    test_prob: np.ndarray,
    y_true: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, LogisticRegression]:
    """
    Fits univariate Platt scaling (temperature + bias calibration) on logit-transformed probabilities.
    """
    z_oof = logit(np.clip(oof_prob, EPS, 1.0 - EPS)).reshape(-1, 1)
    z_test = logit(np.clip(test_prob, EPS, 1.0 - EPS)).reshape(-1, 1)

    cal = LogisticRegression(C=1.0, solver="lbfgs")
    cal.fit(z_oof, y_true)

    oof_cal = np.clip(cal.predict_proba(z_oof)[:, 1], FLOOR, CEIL)
    test_cal = np.clip(cal.predict_proba(z_test)[:, 1], FLOOR, CEIL)
    return oof_cal, test_cal, cal


def isotonic_calibrate(
    oof_prob: np.ndarray,
    test_prob: np.ndarray,
    y_true: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, IsotonicRegression]:
    """
    Fits non-parametric isotonic regression to calibrate monotonic probability output.
    """
    iso = IsotonicRegression(out_of_bounds="clip", y_min=FLOOR, y_max=CEIL)
    iso.fit(oof_prob, y_true)

    oof_cal = np.clip(iso.predict(oof_prob), FLOOR, CEIL)
    test_cal = np.clip(iso.predict(test_prob), FLOOR, CEIL)
    return oof_cal, test_cal, iso
