"""
Stage 2: 4-Seed 10-Fold Domain GBDT Zoo across 5 tree architectures.
Generates checkpoints/gbdt_zoo_4seed.npz and submission_s2_gbdt_zoo_0.73733.csv.
"""

import os
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from catboost import CatBoostClassifier
from xgboost import XGBClassifier
import lightgbm as lgb

from src.config import (
    ID_COL,
    TARGET,
    get_default_dataset_paths,
)
from src.features.pipeline import engineer_features
from src.features.encoding import extract_domain_feature_subsets, screen_features
from src.models.gbdt import fit_gbdt_runner
from src.ensemble.calibration import platt_scaling_calibrate
from src.metrics import competition_score


def run_stage2(
    train_path: str = None,
    test_path: str = None,
    output_dir: str = "checkpoints",
    sub_dir: str = "submissions",
    seeds: Tuple[int, ...] = (42, 100, 2024, 777),
    n_splits: int = 10,
) -> float:
    """Executes Stage 2 4-Seed 10-Fold Domain GBDT Zoo."""
    print("Stage 2: 4-Seed 10-Fold Domain GBDT Zoo")

    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(sub_dir, exist_ok=True)

    if not train_path or not test_path:
        train_path, test_path = get_default_dataset_paths()

    train_raw = pd.read_csv(train_path)
    test_raw = pd.read_csv(test_path)

    X_train_feat, X_test_feat, cat_cols, _ = engineer_features(train_raw, test_raw)
    target_col = TARGET if TARGET in X_train_feat.columns else "Target"
    y_true = X_train_feat[target_col].to_numpy(int)

    drop_meta = [c for c in [ID_COL, target_col] if c in X_train_feat.columns]
    X_train_clean = X_train_feat.drop(columns=drop_meta)
    X_test_clean = X_test_feat.drop(columns=[c for c in [ID_COL] if c in X_test_feat.columns])

    print("Screening top 300 features on numeric signals", flush=True)
    selected_cols = screen_features(X_train_clean, y_true, cat_cols, k_top=300, seed=42)
    X_tr = X_train_clean[selected_cols].copy()
    X_te = X_test_clean[selected_cols].copy()
    active_cats = [c for c in cat_cols if c in selected_cols]

    dom2_cols, dom3_cols, dom_triage_cols = extract_domain_feature_subsets(list(X_tr.columns))

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    folds = list(skf.split(X_tr, y_true))

    architectures = [
        ("cb_domain3", CatBoostClassifier, {"iterations": 800, "depth": 6, "learning_rate": 0.035, "l2_leaf_reg": 4.0, "feature_cols": dom3_cols}),
        ("cb_screened", CatBoostClassifier, {"iterations": 800, "depth": 6, "learning_rate": 0.035, "l2_leaf_reg": 3.0}),
        ("lgb_screened", lgb.LGBMClassifier, {"n_estimators": 750, "learning_rate": 0.030, "num_leaves": 31, "colsample_bytree": 0.65}),
        ("xgb_screened", XGBClassifier, {"n_estimators": 700, "learning_rate": 0.030, "max_depth": 5, "colsample_bytree": 0.65}),
        ("cb_triage", CatBoostClassifier, {"iterations": 750, "depth": 5, "learning_rate": 0.035, "l2_leaf_reg": 5.0, "feature_cols": dom_triage_cols}),
    ]


    zoo_oof: Dict[str, np.ndarray] = {}
    zoo_test: Dict[str, np.ndarray] = {}

    for name, cls_, params in architectures:
        oof, test_pred, _ = fit_gbdt_runner(
            name=name,
            model_cls=cls_,
            base_params=params,
            X_train=X_tr,
            y_train=y_true,
            X_test=X_te,
            folds=folds,
            cat_cols=active_cats,
            seeds=seeds,
        )
        zoo_oof[name] = oof
        zoo_test[name] = test_pred

    raw_oof = np.mean(list(zoo_oof.values()), axis=0)
    raw_test = np.mean(list(zoo_test.values()), axis=0)
    cal_oof, cal_test, _ = platt_scaling_calibrate(raw_oof, raw_test, y_true)

    ll, auc, final_comp = competition_score(y_true, cal_oof)
    print(f"Stage 2 4-seed GBDT zoo score: {final_comp:.5f} (AUC: {auc:.5f}, LL: {ll:.5f})")

    s4_path = os.path.join(output_dir, "gbdt_zoo_4seed.npz")
    np.savez_compressed(s4_path, oof_s4_tree_zoo=cal_oof, test_s4_tree_zoo=cal_test, **zoo_oof)

    sub_path = os.path.join(sub_dir, "submission_s2_gbdt_zoo_0.73733.csv")
    pd.DataFrame({ID_COL: test_raw[ID_COL], "Target": cal_test}).to_csv(sub_path, index=False)
    print(f"Saved {s4_path} and {sub_path}")
    return final_comp


if __name__ == "__main__":
    run_stage2()
